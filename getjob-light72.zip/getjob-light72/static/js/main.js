$(function () {

  $.init();

  $(document).on('click','.alert-text-title', function () {
	    $.alert('企业会很快恢复，先耐心等待~', '报名成功!');
	});

  $('#collect-btn').on('click',function(){
  	$(this).toggleClass('button-fill').toggleClass('button-on');
  });
});
