work:0~12

done1:
1、首页		index.html
2、职位列表	job.html
6、工作管理	job-control.html



消息			message.html
在岗职位		


done2:
4、职位详情	job-detail.html
7、个人中心	mycenter.html
9、评价页		appraise.html
11、企业主页	co-index.html