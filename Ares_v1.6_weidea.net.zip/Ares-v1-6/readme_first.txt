* IMPORTANT NOTE IF YOU UPDATE FROM PREVIOUS VERSION OF ARES (v1.0-1.4)

---------------------------------

Step 1 � Updated Theme files and folders

1) Log with your FTP account
2) Open folder /wp-content/themes
3) Replace theme folder with the new version.

---------------------------------

Step 2 � Regenerating image content

1) Download Regenerating Thumbnails Plugin from http://wordpress.org/extend/plugins/regenerate-thumbnails/
2) Login to your WordPress Dashboard
3) Open Plugins > Add New > Upload and install the plugin
4) Open Tools > Regen. Thumbnails
5) Click on �Regenerate Thumbnails�