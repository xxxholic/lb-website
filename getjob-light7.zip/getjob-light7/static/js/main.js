$(function () {

  $.init();

  // login check
    $("#cbtest").click(function () {
          if ($(this).is(':checked')) {
              $('#cb-btn').removeClass('disabled');
          }
          else {
              $('#cb-btn').addClass('disabled');
          }
   
      });
  // dialog alert
  $(document).on('click','.alert-text-title', function () {
	    $.alert('企业会很快恢复，先耐心等待~', '报名成功!');
	});
  $(document).on('click','.gps-work-on', function () {
      $.alert('GPS定位成功您已到达工作地点范围', '努力加油哦!');
  });
  $(document).on('click','.gps-work-off', function () {
      $.alert('GPS定位成功您已到达工作地点范围', '辛苦啦！');
  });

});
