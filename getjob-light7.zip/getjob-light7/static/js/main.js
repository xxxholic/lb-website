$(function () {

  $.init();

  $(document).on('click','.alert-text-title', function () {
	    $.alert('企业会很快恢复，先耐心等待~', '报名成功!');
	});
  // co-index collect-btn up and down
  $('#collect-btn').on('click',function(){
  	$(this).toggleClass('button-fill').toggleClass('button-on');
  });

  // map list co-detail switch
  $('#p1,#p2,#p3,#p4').on('click',function(){
  	$('#p1,#p2,#p3,#p4,#dp1,#dp2,#dp3,#dp4').removeClass('active');
  	$(this).addClass('active');
  	$('#d'+this.id).addClass('active');
  });

  // login check
  $("#cbtest").click(function () {
        if ($(this).is(':checked')) {
            $('#cb-btn').removeClass('disabled');
        }
        else {
            $('#cb-btn').addClass('disabled');
        }
 
    });

});
