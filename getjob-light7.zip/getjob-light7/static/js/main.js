$(function () {

  $.init();
});
