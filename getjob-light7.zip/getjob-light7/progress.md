work:0~12

done1:
1、首页			index.html
2、职位列表		job.html
6、工作管理		job-control.html



消息				message.html


done2:
4、职位详情		job-detail.html
7、个人中心		mycenter.html
9、评价页			appraise.html
11、企业主页		co-index.html


done3:
0.登陆/1.注册 	login.html
5.个人认证 		auth.html
10.我的薪资 		mymoney.html

todo:
职位列表－地图
更多个人信息